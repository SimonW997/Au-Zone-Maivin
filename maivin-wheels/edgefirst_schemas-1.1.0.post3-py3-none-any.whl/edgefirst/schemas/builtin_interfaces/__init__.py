from .Duration import Duration
from .Time import Time